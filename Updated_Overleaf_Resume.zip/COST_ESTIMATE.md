# Commercial product cost-avoidance estimate

**Central scenario: approximately INR 10.5 crore (10.5841 crore before rounding).**

**Basis: products the owner says would otherwise have been procured, with explicit price and quantity assumptions. No developer-month, outsourced-build, or replacement-development estimates are included.** This is gross vendor-cost avoidance, not audited savings, net ROI, or a reconstructed historical total.

Timing: 6 modeled years for legacy support/Git/TLS. CEIL includes a **one-time perpetual software purchase**, a separate product installation/configuration allowance and 1 year(s) of annual support. There is no CEIL software subscription. These periods are assumptions, not recorded commissioning dates.

## Calculation

| Component | INR crore | Period / status |
| --- | ---: | --- |
| EIL EngDMS: prior procurement/upgrade estimate | 6.0000 | One-time provisional baseline |
| Client Transmittal Portal: prior procurement estimate | 1.5000 | One-time provisional baseline |
| Support on the legacy baseline | 2.2500 | 6 assumed years |
| Paid Git product alternative | 0.2592 | 6 assumed years |
| Paid DV wildcard alternative | 0.0146 | 6 assumed years |
| CEIL-eDMS: on-premise perpetual licence procurement | 0.4086 | One-time software purchase |
| CEIL-eDMS: product installation/configuration | 0.0500 | One-time planning allowance |
| CEIL-eDMS: annual product support | 0.1017 | 1 assumed support year(s) |
| **Total** | **10.5841** | Illustrative combined scenario |

## Separate CEIL product procurement

CEIL-eDMS is a separately deployed subsidiary platform. The comparison is **FileHold DMS On-Premise Perpetual**, purchased outright. At INR 90/USD and 50 illustrative registered users: **INR 40.86 lakh one-time licences + INR 5.00 lakh implementation allowance = INR 45.86 lakh upfront procurement**. Separately, annual support is **INR 10.17 lakh**; only one year is included in the central total.

Licence arithmetic: one USD 10,900 server/five-user bundle + 23 × USD 1,500 two-user packs. Annual support: USD 2,100 + 23 × USD 400. The capacity is 51 registered users because packs cannot be split. MSRP columns in the public CBM Archives DIR-CPO-5831 catalogue, not its Texas purchaser discount. Public US benchmark, not an Indian tender or CEIL quote. Product installation/configuration allowance is an assumption; bespoke application development is excluded.

50 registered users is an illustrative requirement, not a reported CEIL count. Round two-user packs up; 50 requires capacity for 51. The base includes only five concurrent sessions; additional concurrency is unpriced. General commercial on-premise DMS with document workflows and permissions; engineering review, external access, concurrency and integration equivalence require a scoped quote. One licence purchase plus INR 5 lakh assumed product installation/configuration allowance and one year of separately priced support. No cloud or self-hosted software subscription, extra server licence, or six-year CEIL AMC assumption.

These are alternative seat scenarios, not additive purchases:

| Required users / licensed capacity | Upfront procurement, INR lakh | Annual support, INR lakh | Combined scenario, INR crore |
| ---: | ---: | ---: | ---: |
| 50 / 51 | 45.86 | 10.17 | 10.5841 |
| 100 / 101 | 79.61 | 19.17 | 11.0116 |
| 200 / 201 | 147.11 | 37.17 | 11.8666 |

The implementation allowance covers purchasing and configuring the packaged product, not recreating CEIL in custom code. It is not a vendor quote and excludes validation already bundled with the licence. Existing infrastructure is assumed; incremental Windows/SQL licensing, servers, backup, specialist CAD review, external portal modules and extra concurrency are unpriced, not claimed to be free. The base licence is bought once; annual support is never counted as another software purchase. Remove any support charge bundled into a final quote. Lower-tier, open-source and discounted alternatives can reduce procurement costs.

## Other projects: product fit and treatment

| In-house project | Commercial product candidate | Pricing / fit | Treatment |
| --- | --- | --- | --- |
| Additional vendor/contractor/site portals | Oracle Aconex | Quote required for applicable deployment and commercial terms. Document review, supplier collaboration and transmittals are a relevant product category. | May overlap the existing DMS/client portal baseline or one shared product licence. No separate amount added. |
| Complete enterprise mobile app | No verified single ready-made replacement | No procurement amount assumed. Low-code platform prices are not a finished employee-services/PWA/native app product. | Custom product delivery remains an achievement; no avoided product purchase established. |
| Field inspection module | SafetyCulture | Inspection-product candidate; buyer requirements, paid users and applicable plan not established. | A partial mobile use case, not a substitute for the whole enterprise app. Excluded pending a credible purchase scope. |
| AskData AI | Metabase | Pro listed at USD 6,210/year plus USD 130/year per user beyond 10; free self-hosted option exists. | Partial analytics/SQL alternative; Oracle/local-model fit and a paid procurement need are not established. Excluded. |
| EIL Notification Hub | Novu | Cloud Pro starts at USD 30/month; Free supports 10,000 workflow runs/month. Enterprise self-hosting is quote-based. | Paid tier, traffic and deployment requirements are unknown. Excluded; no hypothetical paid purchase assumed. |

A product existing in the market does not by itself establish avoided procurement. These candidates contribute zero until the required product, deployment, paid tier, volume, and purchase alternative are credible. Custom mobile ownership, AI engineering and platform development remain career achievements.

## Other assumptions

- **Prior baseline:** INR 6 crore EngDMS upgrade/procurement and INR 1.5 crore Client Transmittal Portal procurement are carried from the prior CV. No vendor quote was supplied, and current product prices do not validate those values. They remain provisional estimates.
- **Legacy support:** 10% yearly on only 50% of the legacy baseline: INR 37.50 lakh/year. This allocation and rate are assumptions, not contract terms. Remove any support already included in the original procurement estimate. CEIL support is a separate catalogue line; do not apply the legacy percentage again.
- **Git:** owner reports about 100 developers. Compare one paid alternative at USD 4/user/month, not GitHub plus GitLab together. Counts are held constant for the illustrative legacy period. Free alternatives may eliminate this paid-plan counterfactual.
- **TLS:** owner reports about 200 websites. Count 1 illustrative DV wildcard group(s), not one certificate per website, at USD 270/year. Domain coverage is unverified. No exact adoption year is inferred from the reference to SSL becoming compulsory.
- **Price basis:** INR 90/USD is a planning assumption, not current or historical spot FX. Benchmark prices are frozen; taxes, discounts, inflation, volume tiers and renewal changes are not modeled.
- **Gross, not net:** internal engineering, hosting, storage, backups, administration and maintenance costs are not deducted. Paid alternatives are conditional comparisons, not evidence of canceled purchase orders.
- **Overlap:** DMS review, rendition, migration, transmittals and vendor/client/site exchanges can be covered by one product or baseline. Do not charge separately for each module. GitLab, TLS and HAProxy implementation effort, freelance projects and productivity gains receive no additional procurement value.

## Support sensitivity

| Annual support rate on the eligible legacy portion | Combined scenario, INR crore |
| --- | ---: |
| 0% | 8.3341 |
| 5% | 9.4591 |
| 10% | 10.5841 |
| 15% | 11.7091 |

This varies assumed support only, not the unverified baseline, CEIL seats, product suitability or purchase decision. It is not a confidence interval or a proven savings range.

## Primary sources

Checked 2026-09-16. Product price references, not employer contract evidence.

- [GitHub Team pricing](https://github.com/pricing): USD 4 per user/month benchmark; introductory and renewal terms may differ. Frozen for this scenario, not asserted as six years of actual invoicing.
- [PositiveSSL DV wildcard pricing](https://www.positivessl.com/products/positivessl-wildcard): USD 270 listed annual DV wildcard price. One group in the central scenario; 100 websites are not treated as 200 separately paid certificates.
- [OpenText public software and maintenance price list](https://www.opentext.com/assets/documents/en-US/pdf/opentext-department-of-information-resources-contract-dir-cpo-4405-en.pdf): Some Documentum maintenance lines list first-year maintenance at 23% of licence. Context only, not an EIL quote. This model instead assumes 10% on half the provisional baseline.
- [Let's Encrypt service](https://letsencrypt.org/about/): Certificate issuance and automated renewal are available without certificate licence charges. Hosting and operations still have costs.
- [GitLab paid and free plans](https://about.gitlab.com/pricing/): Free self-managed plan and USD 29 Premium seats exist. Premium pricing is excluded from the central estimate; GitHub and GitLab licences are alternatives, not additive savings.
- [Oracle Aconex product scope](https://www.oracle.com/construction-engineering/aconex/): Engineering document/review and supplier collaboration product. Used to establish product-category fit only, not an extra price or full feature-equivalence claim.
- [SafetyCulture inspection platform](https://safetyculture.com/pricing/): Candidate for inspection workflows only. No current price assumed or added.
- [Metabase product pricing](https://www.metabase.com/pricing): Pro USD 6,210/year plus USD 130/user/year beyond the first 10; free self-hosted option also listed. No AI procurement saving added.
- [Novu product pricing](https://novu.co/pricing/): Cloud Pro from USD 30/month; Free has 10,000 workflow runs/month; enterprise self-hosted options require a quote. No notification procurement saving added.
- [FileHold perpetual software and support catalogue](https://cbmarchives.com/DIR-TSO-5831Pricelist.pdf): Page 4 MSRP: perpetual five-user/server bundle USD 10,900; two-user additions USD 1,500 each. Annual FileCare: USD 2,100 base plus USD 400 per two-user addition. Bundle has five concurrent sessions. Public US reseller benchmark; no Texas discount assumed.
- [FileHold perpetual purchase model](https://filehold.com/blog/purchasing-filehold-perpetual-vs-subscription-licenses/): Vendor explains outright perpetual licensing separately from annual support and subscription licensing.
- [FileHold licensing terms](https://filehold.com/software-license-17-1/): Distinguishes cloud, self-hosted subscription and perpetual agreements; use the perpetual alternative here.
- [FileHold registered and concurrent licensing](https://filehold.com/resources/whitepapers/licensing/): Registered-user capacity and concurrent access are different licence dimensions. The CEIL benchmark does not imply 50 simultaneous sessions.

## Reproduce

Edit `cost-model.json`, then run `python3 scripts/cost_estimate.py` (also run by `scripts/build.py`). This regenerates this note and `assets/cost-estimate.json`. Review the manually presented figures in `index.html` and `cv_4.tex` whenever quantities or rates change.
