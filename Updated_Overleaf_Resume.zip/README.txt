Balvinder Singh Nagi - Resume

Upload this ZIP to Overleaf. Set cv_4.tex as the main document and pdfLaTeX as the compiler.
The document is designed for two A4 pages. All required class files are included.

Local build: tectonic cv_4.tex
